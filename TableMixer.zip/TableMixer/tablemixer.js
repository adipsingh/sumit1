var rowsSettedAsHeader;

function init(){
	
	document.getElementById("settings_output").style.display = 'none';
	//document.getElementById("workarea_output").style.display = 'none';
	document.getElementById("headingCover").style.display = 'none';

	var noneSelected = document.querySelector('#headingScale0')
	if (!noneSelected.checked) {
		noneSelected.checked = true;
	}
}

document.getElementById('execute').addEventListener('click', () => {
	
	document.getElementById("dataTable").innerHTML = ''; /* Reset */
	
	var textArea = document.getElementById("InputArea").value;
	var textAreaClean = textArea.replace("'", "");
	//alert(textAreaClean);
	var allRows = textAreaClean.split('\n');

	// --------------------------------------------------------------------

	var columns = 0;

    // Getting maximum column length 
	for (a = 0; a <allRows.length; a++) {
	    var tempColumns = (allRows[a].split('\t')).length;
	    if (tempColumns > columns)
	        columns = tempColumns;
	}

	for (a = 0; a < allRows.length; a++) {

	    var table = document.getElementById("dataTable");
	    var rowValArr = (allRows[a].split('\t'));
	    if (rowValArr.length > 0) {
	        var row = table.insertRow();
	        for (b = 0; b < columns; b++) {
	            var cellVal = rowValArr[b]
	            if (cellVal != '' && cellVal != undefined) {
	                row.insertCell().innerHTML = cellVal;
	            }
	            else {
                    // searching values in next rows in same columns
	                var bal = a + 1;
	                var found=false;
	                for (c = bal; c < allRows.length; c++) {
	                    var tempColumns = (allRows[c].split('\t'))
	                    var foundVal = tempColumns[b];
	                    if (foundVal != '' && foundVal != undefined) {
	                        row.insertCell().innerHTML = foundVal;
	                        var tt = allRows[c];
	                        var index = tt.indexOf(foundVal);	                       
	                        allRows[c] = tt.slice(0, index) + tt.slice(index + foundVal.length);
	                        //var testdata = allRows[c].split('\t');
	                        found = true;
	                        break;
	                    }
	                }
                    // for last empty cells
	                if (found == false) {
	                    row.insertCell().innerHTML = "";
	                }
	            }
	        }
	    }
	}

    // removing empty colums from end
	document.querySelectorAll('table tr').forEach(function (e, i) {
	    if (e.textContent.trim().length == 0) { // if row is empty
	        e.parentNode.removeChild(e);
	    }
	})
})



// SETHEADING FUNCTION:

// -----------------------------------
document.querySelector('.settings_section').addEventListener('change', (e) => {
	
// })
	rowsSettedAsHeader = 0;
// function setHeading(e){
	
	var index = +e.target.value;

	if (rowsSettedAsHeader == index) {
		document.getElementById("headingCover").style.display = 'none';
		rowsSettedAsHeader = 0;
		index = 0;
	} else {
		rowsSettedAsHeader = index;
		document.getElementById("headingCover").style.display = 'block';
	}

	for (var i = 1; i <= 7; i++){
		document.getElementById("headingScale"+i).style.backgroundColor = 'lightgray';
	}
	for (var i = 1; i <= index; i++){
		document.getElementById("headingScale"+i).style.backgroundColor = 'gray';
	}

	var headerCoverHeight;
	if (index !== 0) {
		headerCoverHeight = ((index-1) * 18) + 6;
		// headerCoverHeight = (index * 19);
		// headerCoverHeight = 6 + (18 * index;
		document.getElementById("headingCover").style.height = headerCoverHeight;
	}

})