function init(){

	document.getElementById("settings_output").style.display = 'none';
	document.getElementById("workarea_output").style.display = 'none';
}

function excecution(){
	document.getElementById("settings_output").style.display = 'block';
	document.getElementById("workarea_output").style.display = 'block';
	document.getElementById("settings_input").style.display = 'none';
	document.getElementById("workarea_input").style.display = 'none';
}

function back(){
	document.getElementById("settings_input").style.display = 'block';
	document.getElementById("workarea_input").style.display = 'block';
	document.getElementById("settings_output").style.display = 'none';
	document.getElementById("workarea_output").style.display = 'none';
}

